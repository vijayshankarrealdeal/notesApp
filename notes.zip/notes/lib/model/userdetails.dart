class UserDetails {
  final String uid;
  final String name;
  final String email;
  final String mediaUrl;
  final String timeline;
  final List list;
  final List location;
  final bool isPrivate;
  final int follow;

  UserDetails(
      {this.uid,
        this.follow,
      this.location,
      this.isPrivate,
      this.timeline,
      this.name,
      this.mediaUrl,
      this.email,
      this.list});
  Map<String, dynamic> toJson() {
    return {
      'location': location,
      'follow':follow,
      'uid': uid,
      'name': name,
      'mediaUrl': mediaUrl,
      'email': email,
      'list': list,
      'timeline': timeline,
      'isPrivate': isPrivate,
    };
  }

  factory UserDetails.fromJson(Map<String, dynamic> data) {
    if (data == null) {
      return null;
    } else {
      return UserDetails(
        follow: data['follow'],
          location: data['location'],
          uid: data['uid'],
          name: data['name'],
          email: data['email'],
          list: data['list'],
          mediaUrl: data['mediaUrl'],
          timeline: data['timeline'],
          isPrivate: data['isPrivate']);
    }
  }
}
