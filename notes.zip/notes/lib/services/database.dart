import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:notes/model/userdetails.dart';

abstract class Data {
  Future<void> createUser({UserDetails create});
  Stream userStream();
}

class Database extends Data {
  final String uid;
  final String email;
  Database({this.uid, this.email});
  // ignore: deprecated_member_use
  final _refrence = Firestore.instance;

  //users
  @override
  Future<void> createUser({UserDetails create}) async {
    final path = '/users/$uid';
    await _refrence.doc(path).set(create.toJson());
  }

  @override
  Stream<List<UserDetails>> userStream() {
    return _refrence.collection('users').snapshots().map((event) =>
        event.docs.map((e) => UserDetails.fromJson(e.data())).toList());
  }
}
